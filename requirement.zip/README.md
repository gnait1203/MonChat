# MonChat - 상품처리계 성능/오류 데이터 분석 Q&A

Streamlit + FastAPI + pgvector 기반의 데이터 분석 Q&A 시스템 예제 구현입니다.

## 구성 요소
- UI(Frontend): Streamlit
- API(Backend): FastAPI
- VectorDB: PostgreSQL + pgvector (Docker)
- ETL: Oracle/로그 수집 → 임베딩 → VectorDB 적재, APScheduler

## 빠른 시작
1) 의존성 설치
```bash
python -m venv .venv
. .venv/Scripts/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2) 환경변수 파일 준비
```bash
copy .env.example .env  # Windows
# 필요 값 수정 (DB, 로그 경로 등)
```

3) VectorDB 실행 (Docker)
```bash
cd infra
docker compose up -d
```

4) 백엔드 실행
```bash
uvicorn backend.app.main:app --host %API_HOST% --port %API_PORT% --reload
```

5) 프론트엔드 실행
```bash
streamlit run frontend/app.py --server.port %STREAMLIT_PORT%
```

6) ETL 실행(수동)
```bash
python etl/pipeline.py
```

7) 스케줄러 실행(옵션)
```bash
python etl/sched.py
```

## 환경변수
모든 DB/WAS/DB 로그/임베딩/스케줄 설정은 .env로 관리됩니다. 예시는 `.env.example` 참고.

## 주의
- 최초 실행 시 임베딩 모델 다운로드가 이루어질 수 있습니다(인터넷 필요).
- 실제 Oracle/로그 소스가 없을 경우 해당 수집은 비활성화하세요.
